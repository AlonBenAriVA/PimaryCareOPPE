import pandas as pd
import re

class Compliment:
    '''
    A class and methods to seek letter of compliments from providers
    '''
    def __init__(self,fname = '../assets/ComplimentList.csv'):
        '''
        Read the data from the ComplimentList.csv file
        '''
        self.data = pd.read_csv(fname,skiprows=1)  # proper formatting
        self.data['Employee involved'] = self.data['Employee involved'].apply(lambda x: (re.sub(r'\s+',' ',x)).replace(',','').replace(' ','_'))
        self.comp = self.data.set_index('Employee involved').to_dict()
        self.total = {k.split('_')[0]+'_'+k.split('_')[1]:self.comp['Total'][k]  for k in self.comp['Total'].keys()}
        self.name_string = '_'.join([k for k in self.comp['Total'].keys()])
    
    def get_name(self,LastName,FirstName):
        '''
        A method to find the provider's name and return the number of compliments they got.
        '''
        name = LastName+'_'+FirstName
        response = 'could not be determined automatically'
        if self.total.has_key(name):
            response = self.total[name]
       

        return response
        
###
c = Compliment()
        
