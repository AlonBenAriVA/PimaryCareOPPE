select   a.StaffName,a.StaffSSN, count( distinct a.PatientSSN) as TobaccoScreen
from (
select distinct 
	ThePanel.PatientICN,
	patient.PatientFirstName,
	patient.PatientLastName,
	visit.VisitDateTime,
	hf.HealthFactorDateTime,
	patient.Age,
	patient.PatientSSN,
	ThePanel.PrimaryProviderSID,
	ThePanel.StaffName,
	staff.FirstName,
	staff.LastName,
	staff.ProviderClass,
	staff.ServiceSection,
	staff.StaffSSN,
	staff.Degree,
	hft.HealthFactorType,
	hft.Sta3n,
	hft.HealthFactorCategory
from (
SELECT 
CPPR.Sta3n,
CPPR.PatientSID, 
patient.PatientSSN,  
patient.PatientLastName,  
patient.PatientFirstName,  
s1.StaffName,
s1.LastName
,s1.StaffSID
,patient.PatientICN
,CPPR.PrimaryProviderSID
,s1.StaffSSN
,s1.PositionTitle
,s1.SignatureBlockTitle
,COUNT(*)  AS PanelSize
,COUNT(CASE when CPPR.PCMMAssociateProviderFlag = 'Y' THEN 1 else NULL end) as PreceptedPatients
,COUNT(DISTINCT(CPPR.RPCMMTeamSID)) as Teams
,COUNT(DISTINCT(CPPR.Preceptee_ID)) as Precepts
  FROM [CDWWork].[RPCMM].[CurrentPatientProviderRelationship] CPPR
  inner join CDWWork.NDim.RPCMMTeamRole r1
  on CPPR.PrimaryProviderTeamRoleSID = r1.RPCMMTeamRoleSID
  inner join CDWWork.SStaff.SStaff s1
  on CPPR.PrimaryProviderSID = s1.StaffSID
  inner join CDWWork.SPatient.Spatient as patient
  on patient.PatientSID = CPPR.PatientSID
  where 
    CPPR.sta3n = 612
  AND CPPR.RPCMMTeamCareType Like 'PRIMARY CARE%'
         AND  (r1.PrimaryCarePositionIndicator = 'Y'
                     or r1.TeamRoleCode = '4'  
                     or r1.TeamRoleCode = '25' 
                     )
group by CPPR.Sta3n,
patient.PatientSSN,
patient.ScrSSN,
patient.PatientFirstName,
patient.PatientLastName
,s1.LastName
,s1.StaffName
,s1.StaffSSN
,s1.StaffSID
,s1.PositionTitle
,s1.SignatureBlockTitle,
CPPR.PrimaryProviderSID,
CPPR.PatientSID,
patient.PatientICN )as ThePanel
inner join cdwwork.SPatient.SPatient as patient
	on Patient.PatientSID =  ThePanel.PatientSID
inner join cdwwork.Outpat.visit as visit
	on visit.PatientSID = ThePanel.PatientSID
inner join cdwwork.HF.HealthFactor as hf 
	on visit.visitSID = hf.VisitSID
inner join cdwwork.Dim.HealthFactorType as hft
	on hft.HealthFactorTypeSID = hf.HealthFactorTypeSID
inner join cdwwork.Outpat.VProvider as vprovider 
	on  vprovider.VisitSID = visit.VisitSID
inner join  cdwwork.SStaff.SStaff as staff 
	on staff.StaffSID = ThePanel.PrimaryProviderSID
where hft.HealthFactorType in  ('UNABLE TO CONTACT PT (6 TRIES)','TOBACCO: REFERRAL ALREADY PLACED','TOBACCO: DECLINES MEDICATIONS','TOBACCO: DECLINES 		CLINIC REFERRAL','TOBACCO: ALREADY IN PROGRAM','TOBACCO OFFERRED STOP SMOKING CLINIC','SMOKING CESSATION OTC MEDS EDUCATION','QUIT TOBACCO IN THE 		LAST 12 MONTHS','PT NOT INTERESTED IN OTC CESSATION MEDS','PT INTERESTED IN OTC CESSATION MEDS','F/U INPT TOBACCO - OUTPT QUESTIONS','F/U INPT 		TOBACCO - REFUSES','CURRENT TOBACCO USER','CURRENT SMOKER','CIGARETTE USE PAST 30 DAYS') and
	visit.VisitDateTime >= convert(datetime2(0),dateadd(year,-1,getdate())) and
	hft.Sta3n='612' 
	 ) as a
	group by a.StaffName, a.StaffSSN
	order by a.StaffName
















