select a.StaffName, a.StaffSSN,   count(distinct a.PatientSSN) as ColonCancerScreen
from (
select distinct   
	patient.PatientSSN,
	patient.PatientFirstName,
	patient.PatientLastName,
	patient.Age,
	p.PrimaryProviderSID,
	p.StaffName,
	staff.FirstName,
	staff.LastName,
	staff.ProviderClass,
	staff.ServiceSection,
	staff.StaffSSN,
	staff.Degree,
	hft.HealthFactorType,
	hft.Sta3n,
	hft.HealthFactorCategory
from(
SELECT   
CPPR.Sta3n,
CPPR.PatientSID, 
patient.PatientSSN,  
patient.PatientLastName,  
patient.PatientFirstName,  
patient.PatientICN,
s1.StaffName,
s1.LastName
,s1.StaffSID
,CPPR.PrimaryProviderSID
,s1.StaffSSN
,s1.PositionTitle
,s1.SignatureBlockTitle
,COUNT(*)  AS PanelSize
,COUNT(CASE when CPPR.PCMMAssociateProviderFlag = 'Y' THEN 1 else NULL end) as PreceptedPatients
,COUNT(DISTINCT(CPPR.RPCMMTeamSID)) as Teams
,COUNT(DISTINCT(CPPR.Preceptee_ID)) as Precepts
  FROM [CDWWork].[RPCMM].[CurrentPatientProviderRelationship] CPPR
  inner join CDWWork.NDim.RPCMMTeamRole r1
  on CPPR.PrimaryProviderTeamRoleSID = r1.RPCMMTeamRoleSID
  inner join CDWWork.SStaff.SStaff s1
  on CPPR.PrimaryProviderSID = s1.StaffSID
  inner join CDWWork.SPatient.Spatient as patient
  on patient.PatientSID = CPPR.PatientSID
  where 
    CPPR.sta3n = 612
  AND CPPR.RPCMMTeamCareType Like 'PRIMARY CARE%'
         AND  (r1.PrimaryCarePositionIndicator = 'Y'
                     or r1.TeamRoleCode = '4'  
                     or r1.TeamRoleCode = '25' 
                     )
group by CPPR.Sta3n,
patient.PatientSSN,
patient.ScrSSN,
patient.PatientFirstName,
patient.PatientLastName,
patient.PatientICN
,s1.LastName
,s1.StaffName
,s1.StaffSSN
,s1.StaffSID
,s1.PositionTitle
,s1.SignatureBlockTitle,
CPPR.PrimaryProviderSID,
CPPR.PatientSID ) as p
inner join SPatient.SPatient as patient
	on Patient.PatientSID =  p.PatientSID

inner join lsv.Outpat.visit as visit
	on visit.PatientSID = p.PatientSID

inner join LSV.HF.HealthFactor as hf 
	on visit.visitSID = hf.VisitSID and hf.PatientSID = p.PatientSID

inner join Dim.HealthFactorType as hft
	on hft.HealthFactorTypeSID = hf.HealthFactorTypeSID
inner join Outpat.VProvider as vprovider 
	on  vprovider.VisitSID = visit.VisitSID
inner join  SStaff.SStaff as staff 
	on staff.StaffSID = p.PrimaryProviderSID
where
	( (hft.HealthFactorType = 'REFUSED REFERRAL FOR COLON/SIGMOID') or
	( hft.HealthFactorType = 'order for colonoscopy') or
   (hft.HealthFactorCategory = 'cancer screening') ) and
		visit.VisitDateTime between convert(datetime2(0),dateadd(year,-1,getdate())) and getdate() and  
	hft.Sta3n='612' and 
	(patient.Age>=51 or patient.Age<=75)  
	 ) as a
	 group by a.StaffName, a.StaffSSN
	order by a.StaffName
	
