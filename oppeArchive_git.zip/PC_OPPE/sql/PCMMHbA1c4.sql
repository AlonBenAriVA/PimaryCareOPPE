select a.StaffName, a.StaffSSN,count( distinct a.PatientSSN) as HbA1c
from (
select distinct 
	patient.PatientFirstName,
	patient.PatientLastName,
	visit.VisitDateTime,
	patient.Age,
	patient.PatientSSN,
	p.PrimaryProviderSID,
	p.StaffName,
	staff.StaffSSN,
	staff.FirstName,
	staff.LastName,
	staff.ProviderClass,
	staff.ServiceSection,
	staff.Degree,
	hft.HealthFactorType,
	hft.Sta3n,
	hft.HealthFactorCategory,
	hft.VistaEditDate
from (
SELECT 
CPPR.Sta3n,
CPPR.PatientSID, 
patient.PatientSSN,  
patient.PatientLastName,  
patient.PatientFirstName,  
s1.StaffName,
s1.LastName
,s1.StaffSID
,CPPR.PrimaryProviderSID
,s1.StaffSSN
,s1.PositionTitle
,s1.SignatureBlockTitle
,COUNT(*)  AS PanelSize
,COUNT(CASE when CPPR.PCMMAssociateProviderFlag = 'Y' THEN 1 else NULL end) as PreceptedPatients
,COUNT(DISTINCT(CPPR.RPCMMTeamSID)) as Teams
,COUNT(DISTINCT(CPPR.Preceptee_ID)) as Precepts
  FROM [CDWWork].[RPCMM].[CurrentPatientProviderRelationship] CPPR
  inner join CDWWork.NDim.RPCMMTeamRole r1
  on CPPR.PrimaryProviderTeamRoleSID = r1.RPCMMTeamRoleSID
  inner join CDWWork.SStaff.SStaff s1
  on CPPR.PrimaryProviderSID = s1.StaffSID
  inner join CDWWork.SPatient.Spatient as patient
  on patient.PatientSID = CPPR.PatientSID
  where 
    CPPR.sta3n = 612
  AND CPPR.RPCMMTeamCareType Like 'PRIMARY CARE%'
         AND  (r1.PrimaryCarePositionIndicator = 'Y'
                     or r1.TeamRoleCode = '4'  
                     or r1.TeamRoleCode = '25' 
                     )
group by CPPR.Sta3n,
patient.PatientSSN,
patient.ScrSSN,
patient.PatientFirstName,
patient.PatientLastName
,s1.LastName
,s1.StaffName
,s1.StaffSSN
,s1.StaffSID
,s1.PositionTitle
,s1.SignatureBlockTitle,
CPPR.PrimaryProviderSID,
CPPR.PatientSID
) as p
Inner join cdwwork.SPatient.SPatient as patient
	on Patient.PatientSID =  p.PatientSID
inner join CDWWork.Outpat.visit as visit
	on visit.PatientSID = p.PatientSID
inner join LSV.HF.HealthFactor as hf 
	on visit.visitSID = hf.VisitSID
inner join cdwwork.Dim.HealthFactorType as hft
	on hft.HealthFactorTypeSID = hf.HealthFactorTypeSID
inner join Outpat.VProvider as vprovider 
	on  vprovider.VisitSID = visit.VisitSID
inner join  cdwwork.SStaff.SStaff as staff 
	on staff.StaffSID = p.PrimaryProviderSID
where  
	( hft.HealthFactorCategory in ('HYPOGLYCEMIA SCREENING','OUTSIDE HBA1C CATEGORY') or
	 hft.HealthFactorType in ('ORDER FOR HBA1C') )and
	visit.VisitDateTime >= convert(datetime2(0),dateadd(year,-1,getdate())) and
	hft.Sta3n='612' 

	) as a
group by a.StaffName , a.StaffSSN
order by a.StaffName

