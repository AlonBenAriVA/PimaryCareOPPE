select a.PrimaryProviderName, a.StaffSSN, count(*) as Mammograms
from (
select  distinct 
	ThePanel.PatientSID,
	patient.PatientFirstName,
	patient.PatientLastName,
	visit.VisitDateTime,
	patient.Age,
	patient.PatientSSN,
	ThePanel.PrimaryProviderSID,
	ThePanel.PrimaryProviderName,
	staff.FirstName,
	staff.LastName,
	staff.ProviderClass,
	staff.ServiceSection,
	staff.StaffSSN,
	staff.Degree,
	hft.HealthFactorType,
	hft.Sta3n,
	hft.HealthFactorCategory,
	hft.VistaEditDate
from (
Select  B.*  
From (
Select A.*
,Row_number() over (partition by patientsid order by TeamStatus desc, RelationshipType, TeamRoleRank) as PCRank
From (
SELECT distinct 
ppr1.[Sta3n]
,ppr1.PatientSID
,Pat.PatientICN
,cast([RelationshipStartDateTime] as date) as RelationshipStartDate
,cast([RelationshipEndDateTime] as date) as RelationshipEndDate
,sr1.PhysicianProviderIndicator
,Status1.RPCMMTeamPatientAssignmentStatus as [TeamStatus]
,[TeamAssignmentRequestedStartDateTime]
,[TeamAssignmentActualStartDateTime]
,[TeamAssignmentRequestedEndDateTime]
,t1.RPCMMTeamSID as TeamSID
,t1.rpcmmteam as [TeamName]
,tf1.RPCMMTeamFocus as TeamPurpose
,case
when tr1.TeamRole = 'ASSOCIATE PROVIDER' and Precept.EndDateTime is null then precept.FirstProviderSID
else s1.staffsid
End PrimaryProviderSID
,case
when tr1.TeamRole = 'ASSOCIATE PROVIDER' and Precept.EndDateTime is null then s2.StaffName
else s1.staffname
End PrimaryProviderName
,CASE  
WHEN tr1.TeamRole = 'ASSOCIATE PROVIDER' and precept.FirstProviderSID is not null and Precept.EndDateTime is null THEN 'PRECEPTOR'
ELSE tr1.TeamRole 
END AS PrimaryStandardPosition
,s1.staffname as SecondaryProvider
,s1.StaffSID as SecondaryProviderSID
,RPCMMStaffRole as AssociateStandardPosition
,tr1.TeamRole as ProviderRole
,case
when TeamRole = 'ASSOCIATE PROVIDER' then 1
when (TeamRole = 'PRIMARY CARE PROVIDER' and RPCMMStaffRole = 'PHYSICIAN') 
       or (TeamRole = 'Physician-Attending' and PrimaryCarePositionIndicator = 'Y')   
    or(TeamRole = 'Primary Care Provider' and RPCMMSTaffRole = 'Physician-Attending') then 2
when TeamRole = 'DESIGNATED WH PCP' then 3
when TeamRole = 'PRIMARY CARE PROVIDER' and RPCMMStaffRole = 'PHYSICIAN ASSISTANT (PA)' then 4
when TeamRole = 'PRIMARY CARE PROVIDER' and RPCMMStaffRole = 'NURSE PRACTITIONER (NP)' then 5
else 6
end as TeamRoleRank
,ppr1.[RelationshipType]
,T1.InstitutionSID
,INST.institutioncode
,INST.InstitutionName
,ppr1.[TeamSta6a]
,DIV.DivisionName
,Precept.FirstProviderSID as [PreceptorSID]
,s2.StaffName as [Preceptor]
,p2.TeamPositionDescription PreceptorPosition
,Precept.StartDateTime As PreceptorStartDate
,Precept.EndDateTime as PreceptorEndDate
,[RPCMMTeamMembershipSID]
,[LastModifiedUTCDateTime]
FROM cdwwork.[RPCMM].[RPCMMPatientProviderRelationship] AS ppr1
INNER JOIN [cdwwork].ndim.RPCMMTeam as t1 ON ppr1.RPCMMTeamSID = t1.RPCMMTeamSID
INNER JOIN cdwwork.sstaff.sstaff as s1 ON ppr1.ProviderSID = s1.StaffSID
INNER JOIN [cdwwork].ndim.RPCMMStaffRole as sr1 ON ppr1.RPCMMStaffRoleSID = sr1.RPCMMStaffRoleSID
INNER JOIN [cdwwork].ndim.RPCMMTeamRole as tr1 ON ppr1.RPCMMTeamRoleSID = tr1.RPCMMTeamRoleSID
INNER JOIN [cdwwork].[NDim].[RPCMMTeamPatientAssignmentStatus] as Status1 ON ppr1.RPCMMTeamPatientAssignmentStatusSID = Status1.RPCMMTeamPatientAssignmentStatusSID
INNER JOIN [cdwwork].ndim.RPCMMTeamFocus as tf1 ON t1.RPCMMTeamFocusSID = tf1.RPCMMTeamFocusSID
INNER JOIN [cdwwork].[NDim].[RPCMMTeamCareType] as CareType1 ON t1.RPCMMTeamCareTypeSID = CareType1.RPCMMTeamCareTypeSID
INNER JOIN cdwwork.NDim.rpcmmteamposition as P1 ON ppr1.rpcmmteampositionSID = p1.rpcmmteampositionSID
INNER JOIN cdwwork.SPatient.SPatient AS Pat on ppr1.PatientSID = Pat.PatientSID
INNER JOIN cdwwork.DIM.Institution AS INST ON T1.InstitutionSID = INST.InstitutionSID
LEFT JOIN cdwwork.DIM.Division AS DIV ON INST.InstitutionSID = DIV.InstitutionSID
left outer join cdwwork.RPCMM.ProviderProviderRelationship as Precept on ppr1.RPCMMTeamSID = Precept.RPCMMTeamSID and ppr1.RPCMMTeamMembershipSID = Precept.SecondRPCMMTeamMembershipSID
left outer join cdwwork.sstaff.sstaff as s2 ON Precept.FirstProviderSID = s2.StaffSID
left outer join cdwwork.NDim.rpcmmteamposition as P2 on Precept.FirstRPCMMTeamPositionSID = p2.RPCMMTeamPositionSID
where s1.sta3n = 612
and TeamRole in ('PRIMARY CARE PROVIDER', 'ASSOCIATE PROVIDER', 'DESIGNATED WH PCP', 'PHYSICIAN-ATTENDING')
and Status1.RPCMMTeamPatientAssignmentStatus in ('Active','Pending')
) as A
) as B where PCRank = 1 )as ThePanel

inner join cdwwork.Sstaff.Sstaff as staff
 	on staff.StaffSID = ThePanel.PrimaryProviderSID
inner join cdwwork.SPatient.SPatient as patient
	on Patient.PatientSID =  ThePanel.PatientSID
inner join cdwwork.Outpat.visit as visit
	on visit.PatientSID = ThePanel.PatientSID
inner join cdwwork.HF.HealthFactor as hf 
	on visit.visitSID = hf.VisitSID
inner join cdwwork.Dim.HealthFactorType as hft
	on hft.HealthFactorTypeSID = hf.HealthFactorTypeSID
inner join cdwwork.Outpat.VProvider as vprovider 
	on  vprovider.VisitSID = visit.VisitSID
where  
	hft.HealthFactorType in ('WH ORDER MAMMOGRAM SCREEN HF','WH MAMMOGRAM AFTER AGE 74','WH MAMMOGRAM SCREEN FREQ - 6M',
				'WH MAMMOGRAM DECLINED','WH MAMMOGRAM SCREEN FREQ - 1Y','WH MAMMOGRAM SCREEN FREQ - 2Y',
				'WH MAMMOGRAM SCREEN FREQ - 3Y','WH MAMMOGRAM SCREEN FREQ - 4M',
                                'WH MAMMOGRAM DEFERRED','OUTSIDE MAMMOGRAM ORDERED (CONTRACT)') and
	visit.VisitDateTime >= convert(datetime2(0),'01/01/2016') and
	hft.Sta3n='612' and 
	(patient.Age>=51 or patient.Age<=75)  and 
	staff.Degree <> 'NP'
) as a
group by a.PrimaryProviderName ,a.StaffSSN
order by a.PrimaryProviderName	
 





