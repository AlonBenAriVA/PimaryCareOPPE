import pyodbc
import pandas as pd
from os import chdir,getcwd,listdir
from time import ctime
class GetSQL():
    '''
    A method to connect to the VA's CDW from a CentoOS linux box I have. 
    Firstly  -  get the correct driver (from VINCILinux@va.gov).
    Windows users might want to Driver = {SQL Server}
    This is built with snippet from Jon.Dukert@va.gov and Jason.Brown7@va.gov
    '''
    def __init__(self,driver='ODBC Driver 17 for SQL Server',server = 'VHACDWA01.vha.med.va.gov',database = 'CDWWork'):
        '''
        Initiated a connection to the database
        Some users may wish to use driver = 'SQLServer'
        '''
        self.TO_SQL = '../sql'
        self.TO_SRC = '../src'
        self.TO_CSVs = '../CSVs'
        try:
            q_string  = 'DRIVER={'+driver+'};SERVER='+server+';DATABASE='+database+';Trusted_connection=yes;Integrated Security=SSP'
            self.conn = pyodbc.connect(q_string)
        except:
            print('Failed to connect')
        
        chdir(self.TO_SQL)
        self.sqlList = listdir(getcwd())
        chdir(self.TO_SRC)

    def SQLsubmit(self,sql):
        '''
        Submit an sql query
        '''
        t0= pd.to_datetime(ctime())
        df = pd.read_sql_query(sql=sql,con=self.conn)
        print(pd.to_datetime(ctime())-t0)
        return df


    def SQLread(self,fname):
        '''
        A method to read a .sql file and return it as a string. The mothed will read from the sql directory 
        '''
        chdir(self.TO_SQL)
	print(getcwd())
        with open (fname,'r') as sqlfile:
            sql = ' '.join(line.rstrip() for  line in sqlfile)
        chdir(self.TO_SRC)
        sqlfile.close()
	print(getcwd())
        return sql.replace('\t',' ')


    def to_csv(self, sql,csvfile):
        '''
        A method to write an SQL query into a csvfile.csv file
        '''
       
        try:
             self.SQLsubmit(sql).to_csv(csvfile)
        except:
            print('could not save the file as csv')
        

    def to_csv(self,sql_df,csvfile):
        '''
        A method to write a dataframe from an SQL query into a data frame
        '''
        try:
            sql_df.to_csv(csvfile)
        except:
            print('could not save the file as csv')


    def BuildCSVs(self,fname):
        '''
        A method tasked with building a csv file from a query and putting it in the right place.
        '''
        chdir(self.TO_SQL)
        sql = self.SQLread(fname)
        chdir(self.TO_CSVs)
        try:
            self.SQLsubmit(sql).to_csv((fname.split('.')[0]+'.csv'))
        except:
            print('could not query '+fname)
     
        chdir(self.TO_SRC)
    
    def BuildCSVAll(self):
        '''
        Build all  csv files and put the in the right directory
        '''
        T0 = pd.to_datetime(ctime())
        print(T0)
        for sqlfile in self.sqlList:
            print(sqlfile)
            self.BuildCSVs(sqlfile)
        print(T0-pd.to_datetime(ctime()))
        print('we are done')

####run 
g = GetSQL()
#T0 = pd.to_datetime(ctime())
#print(T0)
g.BuildCSVAll()
#fname = 'ThePanel2.sql'
#g.BuildCSVs(fname)
#print(pd.to_datetime(ctime()))

#print(T0-pd.to_datetime(ctime()))
#print('we are done')
