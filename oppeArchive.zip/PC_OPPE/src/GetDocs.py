import pandas as pd
from os import chdir,listdir,getcwd, mkdir, remove, path
from shutil import rmtree, copyfile
import re

class GetDocs:
	"""
	A set of methods to return obejcts of names by location for me to send emails with the 		correct reports
	"""
	def __init__(self):
		self.err_site = {'CHICO':'CHICO','FF':'FF_MI','MCC':'MCC','MI':'FF_MI','FF/MI':'FF_MI',
			'MTZ':'MTZ', 'OAK':'OAK','OAK UC':'OAK','RDG':'RDG','SAC':'SAC',
				'UC MTZ':'MTZ','UC OAK':'OAK','UC RDG':'RDG','YC':'YC'}
		chdir('../assets')
		self.fname = 'PrimaryCareDoctors.csv'
		self.data = pd.read_csv(self.fname)
		self.fix_names()
		chdir('../src')
		self.leaders = []
		self.doc2site = []
		self.doc_dict={}
		self.get_docs()
		chdir('tex_files/pdfReport')
		self.concat_docs = '_'.join(list(set([d.split('.')[0] for d in listdir(getcwd())])))
		chdir('../..')
		self.get_fullname()
		
		
	def fix_names(self):
		fixed = []
		for  s in self.data['Site']:
			fixed.append(self.err_site[s])
			
		self.data['Site'] = fixed
	def get_fullname(self):
		'''
		A method to match  rovider name to pdf file name
		'''
		
		for f in self.concat_docs.split('_'):
			for k in self.doc2site.keys():	
				if re.search(k,f)!=None:
					index = re.search(k,f)
					self.doc_dict[k] = f[index.start():].split('_')[0]
					
					
		
	def get_docs(self):
		"""
		A script to read the doc list from Donnalee Burch list and return dictionalry 			obejcts 		
		"""
		pc_dict = self.data.to_dict(orient = 'records')
		self.leaders =  [l for l in pc_dict if l['Lead']=='YES']
		
		#
		doc2site = {self.data['Name'].ix[i].upper():self.data['Site'].ix[i]  for i in self.data.index}
			
		self.doc2site  = {k.replace(', ',','):doc2site[k]  for k in doc2site.keys()}
		


	def assign2site(self):
		'''
		A method to pack each report to its respective  site (directory)
		'''
		'''
		Erase directories and re-create them
		'''
		chdir ('tex_files/pdfReport')
		for dir in self.data['Site'].unique().tolist():
			if path.exists(dir):
				rmtree(dir)
				mkdir(dir)
				print(dir)
			else:
				mkdir(dir)
				print(dir)
		'''
		Find files and copy into correct directory
		'''
		#self.concat_docs = '_'.join(list(set([d.split('.')[0] for d in listdir(getcwd())])))
		
		
		for k in self.doc_dict:
			if path.isfile(self.doc_dict[k]+'.pdf'):
				print ('%s  -exists' %k)
				loc = self.doc2site[k]
				copyfile(self.doc_dict[k]+'.pdf',loc+'/'+self.doc_dict[k]+'.pdf')
				print('copied: %s' % self.doc_dict[k]+'.pdf')
				
			else:
				print('%s does not exist' %k)
				
		chdir('../..')
####
d = GetDocs()	
d.assign2site()
