import pandas as pd
from os import chdir,listdir, getcwd
from numpy import sum
import TMS as tms
import Compliment as comp


class GetReport:
    """
    A Class to generate report for each primary care provider
    """
    def __init__(self):
        chdir('../CSVs')
        self.ThePanel = pd.read_csv('ThePanel4.csv')
        csv_list = listdir(getcwd())
        loc = [i for i,j in enumerate(csv_list) if csv_list[i]=='ThePanel4.csv'][0]
        csv_list.pop(loc) #
        #
        for csv in csv_list:
            table = pd.read_csv(csv)
            print(csv)
            self.ThePanel = self.ThePanel.merge(table, on=['StaffName','StaffSSN'],how = 'left')
        # remove coloumns
        cols_in = [i for i,c in enumerate(self.ThePanel.columns) if c[0:8]!='Unnamed:']
        self.ThePanel = self.ThePanel.ix[:,cols_in]
           
        chdir('../src')
        self.temp = file('../assets/template8.tex','r').read()   # read the latex template
        self.section = 'Primary Care'
        #self.bls_date = '01/01/2017',
        #self.acls_date = '01/01/2017'
	self.end_date = '10/18'
	#
	self.prop_tab = pd.DataFrame()
	self.prop_tab['StaffName'] = self.ThePanel['StaffName']
	self.prop_tab['PanelSize'] = self.ThePanel['PanelSize']
	#self.prop_tab['OnAspirin'] = self.ThePanel['OnAspirin']/self.ThePanel['PanelSize'].astype(float)
	self.prop_tab['TobaccoScreen'] = self.ThePanel['TobaccoScreen']/self.ThePanel['PanelSize'].astype(float)
	self.prop_tab['RetinalScreen'] = self.ThePanel['RetinalScreen']/self.ThePanel['PanelSize'].astype(float)
	self.prop_tab['ColonCancerScreen'] = self.ThePanel['ColonCancerScreen']/self.ThePanel['PanelSize'].astype(float)
	self.prop_tab['Mammograms'] = self.ThePanel['Mammograms']/self.ThePanel['Female_patients'].astype(float)
	#self.prop_tab['PAPoffered'] = self.ThePanel['PAPoffered']/self.ThePanel['Female_patients'].astype(float)
      
        
	#
    	self.rank_tab =pd.DataFrame()
    	self.rank_tab['StaffName'] = self.ThePanel['StaffName']
    	self.rank_tab['StaffSSN'] = self.ThePanel['StaffSSN']
    	self.rank_tab = pd.concat([self.rank_tab,self.ThePanel.iloc[:,2:].rank(axis=1,method='min',na_option='keep').apply(self.get_max)],axis=1)
    	#
    	chdir('../assets')
    	bls = tms.TMS('BLSreport.csv')
        bls.write_json('bls.json')
        self.bls = bls.read_json('bls.json')   # dictionary for bls providers
        # acls data
        acls = tms.TMS('ACLSreport.csv')
        acls.write_json('acls.json')
        self.acls = bls.read_json('acls.json')
    	chdir('../src')
    
    def get_max(self,c):
    	"""
    	return the corrected to maximal value 
    	"""
    	return  c/c.max(axis=0)

    def format_report(self):
        '''
        A method to create a latex/pdf from the report
        ssn - provider ssn
        section - Provider section
        bls_date, acls_date  -  data from TMS
        period_date -  last date period
        '''
        # preliminaries
	
        title = 'OPPE '+self.section
        
        #
        
	chdir('tex_files')
        for i in self.ThePanel.index:
		name = self.ThePanel.ix[i]['StaffName']
		if (self.bls.has_key(name)):
           	 	BLSDate = 'BLS Expiration Date: '+self.bls[name][-1]
        	else:
           		 BLSDate = 'BLS Expiration Date: '+' cannot be inferred automatically'
                                                        
        	if (self.acls.has_key(name)):
             		ACLSDate = 'ACLS Expiration Date: ' +self.acls[name][-1]
        	else:
            		ACLSDate = 'ACLS Expiration Date: '+'cannot be inferred automatically'
            	lastname = name.split(',')[0]
            	firstname = name.split(',')[1]
            	response = 'Compliment Letters/Visit: '+str(comp.c.get_name(lastname,firstname))
            	#
		tab = pd.DataFrame(self.ThePanel.ix[i][2:]) #	# raw numbers
		#tab = pd.DataFrame(self.rank_tab.ix[i][2:])   	# ranking
		#tab = pd.DataFrame(self.prop_tab.ix[i][2:])	#proportions
		tab.columns = ['measure']
		tab.dropna(inplace = True)
		# format the report
		report = self.temp%{'name':name,
		                    'start_date': (pd.to_datetime(self.end_date,format = '%m/%y')+pd.Timedelta('-180 days')).strftime(format = '%m/%y'),
		                    'end_date':self.end_date,
		                    'title':title,
		                    'response':response,
		                    'tab':tab.to_latex(),
		                    'BLSDate':BLSDate,
		                    'ACLSDate':ACLSDate}
		file(name+'.tex','w').write(report)
        # save the report.as tex file.
        chdir('..')


            
########run #######
report = GetReport()
report.format_report()
## run from the cli.
###find -name "*.tex" -exec pdflatex -output-directory=pdfReport '{}' \; 
