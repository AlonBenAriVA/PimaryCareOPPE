import pandas as pd
from os import chdir
import json
import re

class TMS:
    '''
    A class to create a jason file from the TMS report Walter Cristale gave me.
    '''
    def __init__(self,fname='../assets/BLSreport.csv'):
        '''
        read the BLS file
        '''
        self.data = pd.read_csv(fname)[['User Name','Status','Organization Description','Email Address','Required Date']]
        self.data['User Name'] = self.data['User Name'].apply(lambda x: x.split(',')[0]+', '+x.split(' ')[1])
        self.d = {self.data['User Name'].ix[i]: [self.data['Status'].ix[i],
                                                 self.data['Email Address'].ix[i],
                                                 self.data['Organization Description'].ix[i],
                                                 self.data['Required Date'].ix[i]]
                                                 for i in self.data.index}
    
        
        self.name_string = '_'.join([last.split(',')[0]+'_'+last.split(' ')[1]+'_'  for last in self.d.keys()])

    def write_json(self,fname):
        '''
        Write the json  object
        '''
        with open (fname,'w') as output:
            json.dump(self.d,output,indent = 4)
     
    
    def find_name(self,last_name,first_name):
        '''
        return a mask of finding a match on a name
        '''
        #
        response = 'Could not reconcile training automatically'
        
      
        NAME = last_name+'_'+first_name
        if re.search(NAME, self.name_string):
            print(self.d[last_name+', '+first_name])
            
        else:
            print(response)
            
        
    def read_json(self,fname):
        '''
        A method to read a json file into a dictionary
        '''
        with open(fname) as output:
            json_data = json.load(output)
        return json_data

        
### run 
tms = TMS()
#fname = '../output/BLSreport.csv' # source of BLS
#fname = '../output/ACLSreport.csv' # source of BLS
#tms = TMS(fname)
#tms.write_json('bls.json') # dump the json file
#tms.read_json
